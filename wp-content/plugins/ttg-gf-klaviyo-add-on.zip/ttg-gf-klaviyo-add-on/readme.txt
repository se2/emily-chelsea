﻿=== Gravity Forms Klaviyo ===
Contributors: EFE Technology
Donate link: http://efe.com.vn
Tags: klaviyo,gravity forms,forms
Requires at least: 4.0
Tested up to: 4.9
Stable tag: 4.0.2
License: GPLv2 or later

Easily integrate Klaviyo with your Gravity Forms.

== Description ==

[Klaviyo](https://www.klaviyo.com/)
Sell more by using data to drive your marketing

Klaviyo makes it easy for ecommerce marketers to target, personalize, measure and optimize email and Facebook campaigns. And it only takes a few minutes to get started.

INTEGRATE KLAVIYO WITH GRAVITY FORMS
If you use Klaviyo email service and the Gravity Forms plugin, you’re going to want this plugin!

Integrate your Gravity Forms forms so that when users submit a form entry, the entries get added to Klaviyo. Link Email, First Name, Last Name with Klaviyo!

== Screenshots ==

1. You can easily configure the field mapping for export to Klaviyo using Feeds.
2. View of the Gravity Forms Klaviyo Settings screen.
3. View of Form Feeds. You can have multiple feeds for each form.

== Installation ==

Upload the Gravity Forms Klaviyo plugin to your blog, Activate it, then enter your Klaviyo public API key and private API key.

== Changelog ==
= 1.1 =
Update Klaviyo API v2
= 1.1 =
* Tested for support for Wordpress 4.9.1
