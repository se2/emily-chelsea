<?php

/**
 * ACF Options Page
 *
 * @category   ACF
 * @author     TTG
 * @link       https://technologytherapy.com/
 */

if (function_exists('acf_add_options_page')) {

	acf_add_options_page(array(
		'page_title' => 'Theme Options',
		'menu_title' => 'Theme Options',
		'menu_slug'  => 'theme-options',
		'capability' => 'edit_posts',
		'redirect'   => false,
	));
}
